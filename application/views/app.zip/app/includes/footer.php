<footer class="main-footer">
  <strong>Copyright &copy; 2023-<?= date('Y'); ?> <a href="<?= base_url(); ?>">Simran Group</a>.</strong> All rights reserved.
</footer>