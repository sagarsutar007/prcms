
<div style="width: 80%;padding: 40px; font-size: 16px;margin: 0px auto; padding: 20px; background: #d8d8d8;">
    <div style="width: 700px; margin: 0px auto; background: #ffffff; border-radius: 15px; padding: 30px 20px;">
        <?= html_entity_decode($data); ?>
    </div>
</div>
        